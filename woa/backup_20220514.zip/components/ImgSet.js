import ch0 from 'images/ch/ch0.png';
import ch1 from 'images/ch/ch1.png';
import ch2 from 'images/ch/ch2.png';
import ch3 from 'images/ch/ch3.png';
import ch4 from 'images/ch/ch4.png';
import ch5 from 'images/ch/ch5.png';
import ch6 from 'images/ch/ch6.png';
import ch7 from 'images/ch/ch7.png';
import ch8 from 'images/ch/ch8.png';
import ch9 from 'images/ch/ch9.png';
import ch10 from 'images/ch/ch10.png';
import ch11 from 'images/ch/ch11.png';
import ch12 from 'images/ch/ch12.png';
import ch13 from 'images/ch/ch13.png';
import ch14 from 'images/ch/ch14.png';
import ch15 from 'images/ch/ch15.png';
import ch16 from 'images/ch/ch16.png';
import ch17 from 'images/ch/ch17.png';
import ch18 from 'images/ch/ch18.png';
import ch19 from 'images/ch/ch19.png';
import ch99 from 'images/ch/ch99.png';
import ch100 from 'images/ch/ch100.png';
import ch101 from 'images/ch/ch101.png';
import ch102 from 'images/ch/ch102.png';
import ch103 from 'images/ch/ch103.png';
import ch104 from 'images/ch/ch104.png';
import ch105 from 'images/ch/ch105.png';

import ch_style0 from 'images/ch_style/ch_style0.png';
import ch_style1 from 'images/ch_style/ch_style1.png';
import ch_style2 from 'images/ch_style/ch_style2.png';
import ch_style3 from 'images/ch_style/ch_style3.png';
import ch_style4 from 'images/ch_style/ch_style4.png';
import ch_style5 from 'images/ch_style/ch_style5.png';
import ch_style6 from 'images/ch_style/ch_style6.png';
import ch_style7 from 'images/ch_style/ch_style7.png';
import ch_style8 from 'images/ch_style/ch_style8.png';
import ch_style9 from 'images/ch_style/ch_style9.png';
import ch_style10 from 'images/ch_style/ch_style10.png';
import ch_style11 from 'images/ch_style/ch_style11.png';
import ch_style12 from 'images/ch_style/ch_style12.png';
import ch_style13 from 'images/ch_style/ch_style13.png';
import ch_style14 from 'images/ch_style/ch_style14.png';
import ch_style15 from 'images/ch_style/ch_style15.png';
import ch_style16 from 'images/ch_style/ch_style16.png';
import ch_style17 from 'images/ch_style/ch_style17.png';
import ch_style18 from 'images/ch_style/ch_style18.png';
import ch_style19 from 'images/ch_style/ch_style19.png';
import ch_style99 from 'images/ch_style/ch_style99.png';
import ch_style100 from 'images/ch_style/ch_style100.png';
import ch_style101 from 'images/ch_style/ch_style101.png';
import ch_style102 from 'images/ch_style/ch_style102.png';
import ch_style103 from 'images/ch_style/ch_style103.png';
import ch_style104 from 'images/ch_style/ch_style104.png';
import ch_style105 from 'images/ch_style/ch_style105.png';

import ring_ from 'images/ring/ring_.png';
import ring0 from 'images/ring/ring0.png';
import ring1 from 'images/ring/ring1.png';
import ring2 from 'images/ring/ring2.png';
import ring3 from 'images/ring/ring3.png';
import ring4 from 'images/ring/ring4.png';
import ring5 from 'images/ring/ring5.png';
import ring6 from 'images/ring/ring6.png';
import ring7 from 'images/ring/ring7.png';

import sring0 from 'images/sring/sring0.png';
import sring1 from 'images/sring/sring1.png';
import sring2 from 'images/sring/sring2.png';
import sring3 from 'images/sring/sring3.png';
import sring4 from 'images/sring/sring4.png';
import sring5 from 'images/sring/sring5.png';
import sring6 from 'images/sring/sring6.png';
import sring7 from 'images/sring/sring7.png';
import sring10 from 'images/sring/sring10.png';

import ssring0 from 'images/ssring/ssring0.png';
import ssring1 from 'images/ssring/ssring1.png';
import ssring2 from 'images/ssring/ssring2.png';
import ssring3 from 'images/ssring/ssring3.png';
import ssring4 from 'images/ssring/ssring4.png';
import ssring5 from 'images/ssring/ssring5.png';
import ssring6 from 'images/ssring/ssring6.png';
import ssring7 from 'images/ssring/ssring7.png';
import ssring8 from 'images/ssring/ssring8.png';
import ssring9 from 'images/ssring/ssring9.png';
import ssring10 from 'images/ssring/ssring10.png';

export const chImg = [
  ch0,ch1,ch2,ch3,ch4,ch5,ch6,ch7,ch8,ch9,ch10,
  ch11,ch12,ch13,ch14,ch15,ch16,ch17,ch18,ch19,
  ch99,ch100,ch101,ch102,ch103,ch104,ch105
];
export const chStyleImg = [
  ch_style0,ch_style1,ch_style2,ch_style3,ch_style4,ch_style5,ch_style6,ch_style7,ch_style8,ch_style9,ch_style10,ch_style10,ch_style11,ch_style12,ch_style13,ch_style14,ch_style15,ch_style16,ch_style17,ch_style18,ch_style19,
  ch_style99,ch_style100,ch_style101,ch_style102,ch_style103,ch_style104,ch_style105
];
export const ringImg = [
  ring0,ring1,ring2,ring3,ring4,ring5,ring6,ring7,ring_
];
export const sringImg = [
  sring0,sring1,sring2,sring3,sring4,sring5,sring6,sring7,sring10
];
export const ssringImg = [
  ssring0,ssring1,ssring2,ssring3,ssring4,ssring5,ssring6,ssring7,ssring8,ssring9,ssring10
];